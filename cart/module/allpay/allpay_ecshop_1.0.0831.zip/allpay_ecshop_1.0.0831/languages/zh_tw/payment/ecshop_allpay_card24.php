<?php


global $_LANG;

$_LANG['ecshop_allpay_card24'] = '<font color=blue>歐付寶 ALLPAY 信用卡 分24期</font>';
$_LANG['ecshop_allpay_card24_desc'] = ' 歐付寶 ALLPAY - <font color=red> 信用卡支付</font>';
$_LANG['ecshop_allpay_card24_test_mode'] = '測試模式？';
$_LANG['ecshop_allpay_card24_test_mode_range']['Yes'] = '是';
$_LANG['ecshop_allpay_card24_test_mode_range']['No'] = '否';
$_LANG['ecshop_allpay_card24_account'] = '商店代號(必填)';
$_LANG['ecshop_allpay_card24_iv'] = '歐付寶 ALLPAY IV(必填)';
$_LANG['ecshop_allpay_card24_key'] = '歐付寶 ALLPAY KEY(必填)';

$_LANG['pay_button'] = '歐付寶 ALLPAY 信用卡(分24期)付款';

$_LANG['text_goods'] = '網路商品一批';
$_LANG['text_currency'] = '元';
$_LANG['text_paid'] = '付款完成';
