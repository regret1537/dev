<?php


global $_LANG;

$_LANG['ecshop_allpay_tuu'] = '<font color=blue>歐付寶 ALLPAY 儲值消費</font>';
$_LANG['ecshop_allpay_tuu_desc'] = ' 歐付寶 ALLPAY - <font color=red> 儲值消費</font>';
$_LANG['ecshop_allpay_tuu_test_mode'] = '測試模式？';
$_LANG['ecshop_allpay_tuu_test_mode_range']['Yes'] = '是';
$_LANG['ecshop_allpay_tuu_test_mode_range']['No'] = '否';
$_LANG['ecshop_allpay_tuu_account'] = '商店代號(必填)';
$_LANG['ecshop_allpay_tuu_iv'] = '歐付寶 ALLPAY IV(必填)';
$_LANG['ecshop_allpay_tuu_key'] = '歐付寶 ALLPAY KEY(必填)';

$_LANG['pay_button'] = '歐付寶 ALLPAY 儲值消費 ';

$_LANG['text_goods'] = '網路商品一批';
$_LANG['text_currency'] = '元';
$_LANG['text_paid'] = '付款完成';
