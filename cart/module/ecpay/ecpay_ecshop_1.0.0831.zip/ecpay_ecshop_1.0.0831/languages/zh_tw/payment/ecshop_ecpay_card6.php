<?php


global $_LANG;

$_LANG['ecshop_ecpay_card6'] = '<font color="green">綠界 信用卡 分6期</font>';
$_LANG['ecshop_ecpay_card6_desc'] = ' 綠界 - <font color=red> 信用卡支付</font>';
$_LANG['ecshop_ecpay_card6_test_mode'] = '測試模式？';
$_LANG['ecshop_ecpay_card6_test_mode_range']['Yes'] = '是';
$_LANG['ecshop_ecpay_card6_test_mode_range']['No'] = '否';
$_LANG['ecshop_ecpay_card6_account'] = '商店代號(必填)';
$_LANG['ecshop_ecpay_card6_iv'] = '綠界 IV(必填)';
$_LANG['ecshop_ecpay_card6_key'] = '綠界 KEY(必填)';

$_LANG['pay_button'] = '綠界 信用卡(分6期)付款';

$_LANG['text_goods'] = '網路商品一批';
$_LANG['text_currency'] = '元';
$_LANG['text_paid'] = '付款完成';
