<?php

global $_LANG;

$_LANG['ecshop_ecpay_barcode'] = '<font color="green">綠界 超商條碼</font>';
$_LANG['ecshop_ecpay_barcode_desc'] = ' 綠界 - <font color=red> 超商條碼支付</font>';
$_LANG['ecshop_ecpay_barcode_test_mode'] = '測試模式？';
$_LANG['ecshop_ecpay_barcode_test_mode_range']['Yes'] = '是';
$_LANG['ecshop_ecpay_barcode_test_mode_range']['No'] = '否';
$_LANG['ecshop_ecpay_barcode_account'] = '商店代號(必填)';
$_LANG['ecshop_ecpay_barcode_iv'] = '綠界 IV(必填)';
$_LANG['ecshop_ecpay_barcode_key'] = '綠界 KEY(必填)';

$_LANG['pay_button'] = '綠界 超商條碼支付取號';

$_LANG['text_goods'] = '網路商品一批';
$_LANG['text_currency'] = '元';
$_LANG['text_paying'] = '<b>付款中</b> %s\n付款方式: %s\n付款時間: %s\n繳費代碼: %s\n付款截止日: %s\n條碼第一段號碼: %s\n條碼第二段號碼: %s\n條碼第三段號碼: %s\n';
$_LANG['text_paid'] = '付款完成';
